const readline = require("readline");
const Cathedral = require("./Cathedral");
const fm = require("./fileManager");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let cathedrals = fm.loadFromFile();

function menu() {
    console.log("\n1. Add Cathedral");
    console.log("2. Show list");

    rl.question("Option: ", opt => {
        switch (opt) {

            case "1": {
                    rl.question("Name: ", name => {
                        rl.question("Country: ", country => {
                            rl.question("Year build: ", year => {
                                cathedrals.push(
                                    new Cathedral(name, country, parseInt(year))
                                );
                                fm.saveToFile(cathedrals);
                                menu();
                            });
                        });
                    });
                };
                break;

	    case "2":
    		cathedrals.forEach(c => {
        	console.log(`Name: ${c.name}`);
        	console.log(`Country: ${c.country}`);
        	console.log(`Year built: ${c.yearBuilt}`);
        	console.log("-------------------------------");
    		});
    		menu();
    		break;
        }
    });
}

console.log("Cathedral Manager");
menu();
