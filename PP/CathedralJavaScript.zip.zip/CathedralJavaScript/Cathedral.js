class Cathedral {
    constructor(name, country, yearBuilt) {
        this.name = name;
        this.country = country;
        this.yearBuilt = yearBuilt;
    }
}

module.exports = Cathedral;
