const fs = require("fs");
const Cathedral = require("./Cathedral");

const JSON_FILE = "data/cathedrals.json";

function saveToFile(cathedrals) {
    fs.mkdirSync("data", { recursive: true });

    const data = cathedrals.map(c => ({
        name: c.name,
        country: c.country,
        yearBuilt: c.yearBuilt
    }));

    fs.writeFileSync(JSON_FILE, JSON.stringify(data, null, 3));
    console.log("Data save in " + JSON_FILE);
}

function loadFromFile() {
    if (!fs.existsSync(JSON_FILE)) {
        console.log("does not exist, starting empty.");
        return [];
    }

    const raw = fs.readFileSync(JSON_FILE);
    const arr = JSON.parse(raw);

    return arr.map(obj => new Cathedral(obj.name, obj.country, obj.yearBuilt));
}

module.exports = { saveToFile, loadFromFile };
