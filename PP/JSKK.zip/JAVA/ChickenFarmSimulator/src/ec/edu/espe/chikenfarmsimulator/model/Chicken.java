package ec.edu.espe.chikenfarmsimulator.model;

import java.io.Serializable;

public class Chicken implements Serializable { // <--- Implementa Serializable
    private static final long serialVersionUID = 1L; // Identificador de versión

    private int chickenId;
    private String name;
    private String age;
    private String breed;

    public Chicken() {}

    // Constructor simplificado (eliminamos @JsonProperty)
    public Chicken(int chickenId, String name, String age, String breed) {
        this.chickenId = chickenId;
        this.name = name;
        this.age = age;
        this.breed = breed;
    }

    // --- Getters y Setters (Se mantienen) ---
    
    public int getChickenId() { return chickenId; }
    public void setChickenId(int chickenId) { this.chickenId = chickenId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAge() { return age; }
    public void setAge(String age) { this.age = age; }

    public String getBreed() { return breed; }
    public void setBreed(String breed) { this.breed = breed; }
}