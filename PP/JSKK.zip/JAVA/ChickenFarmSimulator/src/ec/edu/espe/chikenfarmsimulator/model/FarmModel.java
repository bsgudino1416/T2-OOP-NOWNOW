package ec.edu.espe.chikenfarmsimulator.model;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import ec.edu.espe.chikenfarmsimulator.model.Chicken; 

public class FarmModel {
    private final String dataFilePath = "data/chickens.dat"; // Cambiado a .dat
    private File dataFile;

    public FarmModel() {
        File dataDir = new File("data");
        if (!dataDir.exists()) {
            dataDir.mkdirs();
        }
        dataFile = new File(dataFilePath);
        initializeFile();
    }

    private void initializeFile() {
        if (!dataFile.exists()) {
            try {
                dataFile.createNewFile();
                // Escribimos una lista vacía para inicializar el archivo binario
                saveAllChickens(new ArrayList<Chicken>()); 
            } catch (IOException ioException) {
                System.err.println("Error al inicializar el archivo de datos: " + ioException.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked") // Para suprimir advertencia de conversión de tipo
    public List<Chicken> getAllChickens() {
        if (dataFile.length() == 0) {
            return new ArrayList<>();
        }
        try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(dataFile))) {
            // Lee el objeto List<Chicken> serializado del archivo
            return (List<Chicken>) objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException exception) {
            // Si hay error (archivo corrupto o estructura cambiada), devuelve lista vacía
            return new ArrayList<>();
        }
    }

    private void saveAllChickens(List<Chicken> chickenList) {
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(dataFile))) {
            // Escribe toda la lista de objetos en el archivo
            objectOutputStream.writeObject(chickenList);
        } catch (IOException ioException) {
            System.err.println("Error al guardar los datos: " + ioException.getMessage());
        }
    }
    
    // --- (Los métodos createChicken, updateChicken, deleteChicken permanecen iguales) ---

    public void createChicken(String name, String age, String breed) {
        List<Chicken> chickenList = getAllChickens();
        int newChickenId = 1;

        if (!chickenList.isEmpty()) {
            Optional<Integer> maxId = chickenList.stream()
                .map(Chicken::getChickenId)
                .max(Integer::compare);
            newChickenId = maxId.orElse(0) + 1;
        }

        Chicken newChicken = new Chicken(newChickenId, name, age, breed);
        chickenList.add(newChicken);
        saveAllChickens(chickenList);
    }

    public boolean updateChicken(int chickenId, String name, String age, String breed) {
        List<Chicken> chickenList = getAllChickens();
        boolean isFound = false;

        for (Chicken chicken : chickenList) {
            if (chicken.getChickenId() == chickenId) {
                chicken.setName(name);
                chicken.setAge(age);
                chicken.setBreed(breed);
                isFound = true;
                break;
            }
        }

        if (isFound) {
            saveAllChickens(chickenList);
        }
        return isFound;
    }

    public boolean deleteChicken(int chickenId) {
        List<Chicken> chickenList = getAllChickens();
        boolean isRemoved = chickenList.removeIf(chicken -> chicken.getChickenId() == chickenId);

        if (isRemoved) {
            saveAllChickens(chickenList);
        }
        return isRemoved;
    }
}