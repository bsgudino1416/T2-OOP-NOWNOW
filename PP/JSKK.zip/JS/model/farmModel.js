const fs = require('fs');
const path = require('path');

// Clase para definir la estructura de un pollo
class Chicken {
    constructor(chickenId, name, age, breed) {
        this.id = chickenId;
        this.name = name;
        this.age = age;
        this.breed = breed;
    }

    toDictionary() {
        return {
            id: this.id,
            name: this.name,
            age: this.age,
            breed: this.breed
        };
    }
}

// Clase para manejar la lógica de datos y el archivo JSON
class FarmModel {
    constructor() {
        // Rutas absolutas para mayor robustez
        const baseDirectory = path.join(__dirname, '..'); // Subir al directorio raíz
        this.folderPath = path.join(baseDirectory, "data");
        this.filePath = path.join(this.folderPath, "chickens.json");
        this.initializeFile();
    }

    initializeFile() {
        if (!fs.existsSync(this.folderPath)) {
            fs.mkdirSync(this.folderPath);
        }
        
        if (!fs.existsSync(this.filePath)) {
            fs.writeFileSync(this.filePath, '[]');
        }
    }

    getAllChickens() {
        try {
            const fileData = fs.readFileSync(this.filePath, 'utf8');
            const jsonList = JSON.parse(fileData);
            
            const chickenList = [];
            for (const item of jsonList) {
                const chickenObject = new Chicken(item.id, item.name, item.age, item.breed);
                chickenList.push(chickenObject);
            }
            return chickenList;
        } catch (error) {
            console.error("Error al leer el archivo JSON:", error.message);
            return [];
        }
    }

    saveAllChickens(chickenList) {
        const dataToSave = [];
        for (const chicken of chickenList) {
            dataToSave.push(chicken.toDictionary());
        }

        const jsonString = JSON.stringify(dataToSave, null, 4);
        fs.writeFileSync(this.filePath, jsonString, 'utf8');
    }

    createChicken(name, age, breed) {
        const chickenList = this.getAllChickens();
        
        // Lógica para el ID automático
        let newId = 1;
        if (chickenList.length > 0) {
            const lastChicken = chickenList[chickenList.length - 1];
            newId = lastChicken.id + 1;
        }
            
        const newChicken = new Chicken(newId, name, age, breed);
        chickenList.push(newChicken);
        this.saveAllChickens(chickenList);
    }

    updateChicken(chickenId, name, age, breed) {
        const chickenList = this.getAllChickens();
        let isFound = false;
        
        for (const chicken of chickenList) {
            if (chicken.id === chickenId) {
                chicken.name = name;
                chicken.age = age;
                chicken.breed = breed;
                isFound = true;
                break;
            }
        }
        
        if (isFound) {
            this.saveAllChickens(chickenList);
        }
            
        return isFound;
    }

    deleteChicken(chickenId) {
        const chickenList = this.getAllChickens();
        const initialLength = chickenList.length;
        
        const newList = chickenList.filter(chicken => chicken.id !== chickenId);
        
        if (newList.length < initialLength) {
            this.saveAllChickans(newList);
            return true;
        }
        return false;
    }
}

// Exportamos ambas clases
module.exports = { Chicken, FarmModel };