// model/farmView.js (Código Completo y Corregido)
const readline = require('readline');

class FarmView {
    constructor() {
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
        });
    }

    // Método para mostrar el menú (Faltaba en el código anterior)
    showMenu() {
        console.log("\n--- 🐔 CHICKEN FARM SIMULATOR 🐔 ---");
        console.log("1. Agregar Pollo");
        console.log("2. Ver Lista de Pollos");
        console.log("3. Editar Pollo");
        console.log("4. Borrar Pollo");
        console.log("5. Salir");
    }

    // Método para obtener la opción del menú
    askForOption() {
        return new Promise(resolve => {
            this.rl.question("Seleccione una opción: ", resolve);
        });
    }

    // Método para preguntar Nombre con validación (Solo texto)
    askForName() {
        return new Promise(resolve => {
            const ask = () => {
                this.rl.question("Nombre (Solo texto): ", nameInput => {
                    // Expresión regular: solo letras, espacios y caracteres básicos (acentos)
                    const textPattern = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;

                    if (textPattern.test(nameInput) && nameInput.trim().length > 0) {
                        resolve(nameInput.trim());
                    } else {
                        // Mensaje de advertencia de solo texto
                        this.showMessage("Advertencia: El nombre debe contener solo texto.");
                        ask(); // Repetir la pregunta
                    }
                });
            };
            ask();
        });
    }

    // Método para preguntar Edad con validación (Solo enteros)
    askForAge() {
        return new Promise(resolve => {
            const ask = () => {
                this.rl.question("Edad (Solo enteros): ", ageInput => {
                    const parsedAge = parseInt(ageInput);

                    // Verifica si es un número, no es NaN, es un entero y no es negativo
                    if (!isNaN(parsedAge) && Number.isInteger(parsedAge) && parsedAge >= 0) {
                        // Lo devolvemos como string para la consistencia del modelo
                        resolve(parsedAge.toString()); 
                    } else {
                        // Mensaje de advertencia de solo enteros
                        this.showMessage("Advertencia: La edad debe ser un número entero válido.");
                        ask(); // Repetir la pregunta
                    }
                });
            };
            ask();
        });
    }

    // Método para preguntar Raza
    askForBreed() {
        return new Promise(resolve => {
            this.rl.question("Raza: ", resolve);
        });
    }

    // Método para preguntar el ID
    askForChickenId() {
        return new Promise(resolve => {
            this.rl.question("Ingrese el ID del pollo: ", chickenIdInput => {
                const chickenId = parseInt(chickenIdInput);
                resolve(isNaN(chickenId) ? -1 : chickenId);
            });
        });
    }

    // Método para mostrar la lista de pollos (Faltaba en el código anterior)
    showChickenList(chickenList) {
        console.log("\nID | Nombre          | Edad | Raza");
        console.log("-".repeat(40));

        if (chickenList.length === 0) {
            console.log("No hay pollos registrados en la granja.");
        } else {
            for (const chicken of chickenList) {
                console.log(`${chicken.id} | ${chicken.name} | ${chicken.age} | ${chicken.breed}`);
            }
        }
    }

    // Método para mostrar mensajes de forma clara
    showMessage(message) {
        console.log(`>> ${message}`);
    }

    // Método para cerrar la interfaz
    closeInterface() {
        this.rl.close();
    }
}

// CORRECCIÓN CLAVE: Exportamos la CLASE directamente, no dentro de un objeto.
// Esto permite usar `const FarmView = require(...)` en el archivo principal.
module.exports = FarmView;