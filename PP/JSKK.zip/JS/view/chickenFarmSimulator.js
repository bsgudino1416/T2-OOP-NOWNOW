// view/chickenFarmSimulator.js (CORREGIDO)

// Aquí asumimos que tienes tu código para manejar las rutas (sys.path.append, etc.)

// --- CORRECCIÓN CLAVE: Usamos la desestructuración ---
// model/farmModel.js exporta { FarmModel, Chicken }
const { FarmModel } = require('../model/farmModel'); // <-- Extraemos FarmModel del objeto
const FarmView = require('../model/farmView');         // <-- Asumimos que exporta solo la clase FarmView

async function main() {
    // 1. Instanciación correcta: Ahora FarmModel es realmente la clase constructora
    const farmModel = new FarmModel();
    const farmView = new FarmView();

    while (true) {
        try { 
            farmView.showMenu();
            const userOption = await farmView.askForOption();

            switch (userOption) {
                case "1":
                    // Agregar con validación
                    const name = await farmView.askForName();
                    const age = await farmView.askForAge();
                    const breed = await farmView.askForBreed();
                    
                    farmModel.createChicken(name, age, breed);
                    farmView.showMessage("Pollo guardado exitosamente.");
                    break;

                case "2":
                    // Ver / Enlistar
                    const allChickens = farmModel.getAllChickens();
                    farmView.showChickenList(allChickens);
                    break;

                case "3":
                    // Editar
                    const currentChickens = farmModel.getAllChickens();
                    farmView.showChickenList(currentChickens);
                    
                    const chickenIdToEdit = await farmView.askForChickenId();
                    
                    const newName = await farmView.askForName();
                    const newAge = await farmView.askForAge();
                    const newBreed = await farmView.askForBreed();
                    
                    const updateSuccess = farmModel.updateChicken(
                        chickenIdToEdit, 
                        newName, 
                        newAge, 
                        newBreed
                    );
                    
                    if (updateSuccess) {
                        farmView.showMessage("Pollo actualizado correctamente.");
                    } else {
                        farmView.showMessage("Error: ID no encontrado.");
                    }
                    break;

                case "4":
                    // Borrar
                    const chickensBeforeDelete = farmModel.getAllChickens();
                    farmView.showChickenList(chickensBeforeDelete);
                    
                    const chickenIdToDelete = await farmView.askForChickenId();
                    const deleteSuccess = farmModel.deleteChicken(chickenIdToDelete);
                    
                    if (deleteSuccess) {
                        farmView.showMessage("Pollo eliminado del sistema.");
                    } else {
                        farmView.showMessage("Error: ID no encontrado.");
                    }
                    break;

                case "5":
                    farmView.showMessage("Saliendo del simulador... ¡Adiós!");
                    farmView.closeInterface();
                    return;

                default:
                    farmView.showMessage("Opción no válida, intente de nuevo.");
            }
        } catch (error) { 
            farmView.showMessage(`[ERROR INESPERADO] ${error.message}`);
        }
    }
}

main();