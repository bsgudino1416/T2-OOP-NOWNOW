import json
import os

class Chicken:
    def __init__(self, chickenId, name, age, breed):
        self.id = chickenId
        self.name = name
        self.age = age
        self.breed = breed

    def toDictionary(self):
        # Convierte el objeto a un formato que JSON entiende
        return {
            "id": self.id,
            "name": self.name,
            "age": self.age,
            "breed": self.breed
        }

class FarmModel:
    def __init__(self):
        # Configuración para encontrar la carpeta data desde cualquier lugar
        baseDirectory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.folderPath = os.path.join(baseDirectory, "data")
        self.filePath = os.path.join(self.folderPath, "chickens.json")
        self.initializeFile()

    def initializeFile(self):
        if not os.path.exists(self.folderPath):
            os.makedirs(self.folderPath)
        
        if not os.path.exists(self.filePath):
            with open(self.filePath, 'w') as fileObject:
                json.dump([], fileObject)

    def getAllChickens(self):
        with open(self.filePath, 'r') as fileObject:
            jsonList = json.load(fileObject)
            
            chickenList = []
            for item in jsonList:
                # Creamos el objeto Pollo con sus datos
                chickenObject = Chicken(item['id'], item['name'], item['age'], item['breed'])
                chickenList.append(chickenObject)
            
            return chickenList

    def saveAllChickens(self, chickenList):
        # Preparamos la lista de diccionarios para guardar
        dataToSave = []
        for chicken in chickenList:
            dataToSave.append(chicken.toDictionary())

        with open(self.filePath, 'w') as fileObject:
            json.dump(dataToSave, fileObject, indent=4)

    def createChicken(self, name, age, breed):
        chickenList = self.getAllChickens()
        
        # Lógica para el ID automático
        if len(chickenList) > 0:
            lastChicken = chickenList[-1]
            newId = lastChicken.id + 1
        else:
            newId = 1
            
        newChicken = Chicken(newId, name, age, breed)
        chickenList.append(newChicken)
        self.saveAllChickens(chickenList)

    def updateChicken(self, chickenId, name, age, breed):
        chickenList = self.getAllChickens()
        isFound = False
        
        for chicken in chickenList:
            if chicken.id == chickenId:
                chicken.name = name
                chicken.age = age
                chicken.breed = breed
                isFound = True
                break
        
        if isFound:
            self.saveAllChickens(chickenList)
            
        return isFound

    def deleteChicken(self, chickenId):
        chickenList = self.getAllChickens()
        newList = []
        isDeleted = False
        
        for chicken in chickenList:
            if chicken.id != chickenId:
                newList.append(chicken)
            else:
                isDeleted = True
        
        if isDeleted:
            self.saveAllChickens(newList)
            return True
        return False