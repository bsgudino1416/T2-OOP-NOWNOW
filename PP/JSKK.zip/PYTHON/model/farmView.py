# model/farmView.py
import re

class FarmView:
    def printMenu(self):
        print("\n--- 🐔 CHICKEN FARM SIMULATOR 🐔 ---")
        print("1. Agregar Pollo")
        print("2. Ver Pollos")
        print("3. Editar Pollo")
        print("4. Borrar Pollo")
        print("5. Salir")
    
    def askOption(self):
        return input("Seleccione una opción: ")

    # Método para preguntar Nombre con validación (Solo texto)
    def askForName(self):
        print("\n--- Ingrese los datos del Pollo ---")
        while True:
            nameInput = input("Nombre (Solo texto): ")
            # Usamos una expresión regular para permitir letras, espacios y acentos.
            textPattern = re.compile(r'^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$')
            
            if textPattern.match(nameInput) and len(nameInput.strip()) > 0:
                return nameInput.strip()
            else:
                self.showMessage("Advertencia: El nombre debe contener solo texto válido.")

    # Método para preguntar Edad con validación (Solo enteros no negativos)
    def askForAge(self):
        while True:
            ageInput = input("Edad (Solo enteros): ")
            try:
                age = int(ageInput)
                if age >= 0:
                    return str(age) # Devolver como string para consistencia con el Modelo
                else:
                    self.showMessage("Advertencia: La edad no puede ser negativa.")
            except ValueError:
                self.showMessage("Advertencia: La edad debe ser un número entero válido.")

    # Método para preguntar Raza con validación (Solo texto)
    def askForBreed(self):
        while True:
            breedInput = input("Raza (Solo texto): ")
            # Reutilizamos la misma lógica de validación de texto
            textPattern = re.compile(r'^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$')
            
            if textPattern.match(breedInput) and len(breedInput.strip()) > 0:
                return breedInput.strip()
            else:
                self.showMessage("Advertencia: La raza debe contener solo texto válido.")

    def askId(self):
        try:
            return int(input("Ingrese el ID del pollo: "))
        except ValueError:
            return -1

    def printList(self, chickens):
        print("\nID | Nombre          | Edad | Raza")
        print("-" * 40)
        
        if len(chickens) == 0:
            print("No hay pollos registrados en la granja.")
        else:
            for chicken in chickens:
                print(f"{chicken.id:<2} | {chicken.name:<15} | {chicken.age:<4} | {chicken.breed}")

    def showMessage(self, message):
        print(f">> {message}")