# view/chickenFarmSimulator.py (CORREGIDO)
import sys
import os

# Ajuste de PATH para encontrar carpetas hermanas
currentDirectory = os.path.dirname(os.path.abspath(__file__))
parentDirectory = os.path.dirname(currentDirectory)
sys.path.append(parentDirectory)

# Importamos las clases necesarias
from model.farmModel import FarmModel
from model.farmView import FarmView

def main():
    farmModel = FarmModel()
    farmView = FarmView()

    while True:
        try:
            farmView.printMenu()
            userOption = farmView.askOption()

            if userOption == "1":
                # Agregar
                name = farmView.askForName()
                age = farmView.askForAge()
                breed = farmView.askForBreed()
                
                farmModel.createChicken(name, age, breed)
                farmView.showMessage("Pollo guardado exitosamente.")

            elif userOption == "2":
                # Ver / Enlistar
                allChickens = farmModel.getAllChickens()
                farmView.printList(allChickens) # <-- CORREGIDO: Usar printList
                

            elif userOption == "3":
                # Editar
                allChickens = farmModel.getAllChickens()
                farmView.printList(allChickens) # <-- CORREGIDO: Usar printList
                
                chickenIdToEdit = farmView.askId()
                
                # Pedimos y validamos los nuevos datos
                newName = farmView.askForName()
                newAge = farmView.askForAge()
                newBreed = farmView.askForBreed()
                
                success = farmModel.updateChicken(chickenIdToEdit, newName, newAge, newBreed)
                
                if success:
                    farmView.showMessage("Pollo actualizado correctamente.")
                else:
                    farmView.showMessage("Error: ID no encontrado.")

            elif userOption == "4":
                # Borrar
                chickensBeforeDelete = farmModel.getAllChickens()
                farmView.printList(chickensBeforeDelete) # <-- CORREGIDO: Usar printList
                
                chickenIdToDelete = farmView.askId()
                success = farmModel.deleteChicken(chickenIdToDelete)
                
                if success:
                    farmView.showMessage("Pollo eliminado del sistema.")
                else:
                    farmView.showMessage("Error: ID no encontrado.")

            elif userOption == "5":
                farmView.showMessage("Saliendo del simulador... ¡Adiós!")
                break
            
            else:
                farmView.showMessage("Opción no válida, intente de nuevo.")
                
        except Exception as e:
            # Captura errores inesperados (ej: fallo de lectura/escritura de JSON)
            farmView.showMessage(f"[ERROR INESPERADO] Ocurrió un fallo en el sistema: {e}")


if __name__ == "__main__":
    main()