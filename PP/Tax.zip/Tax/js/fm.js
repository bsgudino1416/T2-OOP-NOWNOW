const fs = require("fs");
const TaxEntry = require("./TaxEntry");

const JSON_FILE = "data/taxes.json";

function saveToFile(entries) {
    fs.mkdirSync("data", { recursive: true });

    const data = entries.map(e => ({
        description: e.description,
        baseAmount: e.baseAmount,
        taxRate: e.taxRate
    }));

    fs.writeFileSync(JSON_FILE, JSON.stringify(data, null, 3));
    console.log(" Data save in " + JSON_FILE);
}

function loadFromFile() {
    if (!fs.existsSync(JSON_FILE)) {
        console.log("File does not exist, starting empty");
        return [];
    }

    const raw = fs.readFileSync(JSON_FILE);
    const arr = JSON.parse(raw);

    return arr.map(obj => new TaxEntry(obj.description, obj.baseAmount, obj.taxRate));
}

module.exports = { saveToFile, loadFromFile };