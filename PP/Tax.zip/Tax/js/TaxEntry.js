class TaxEntry {
    constructor(description, baseAmount, taxRate) {
        this.description = description;
        this.baseAmount = parseFloat(baseAmount);
        this.taxRate = parseFloat(taxRate);
        this.taxAmount = this.calculateTax();
    }

    calculateTax() {
        return this.baseAmount * this.taxRate;
    }

    updateAmounts() {
        this.taxAmount = this.calculateTax();
    }
}

module.exports = TaxEntry;