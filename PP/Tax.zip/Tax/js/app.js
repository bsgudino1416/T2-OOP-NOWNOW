const readline = require("readline");
const TaxEntry = require("./TaxEntry");
const fm = require("./fm");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let taxEntries = fm.loadFromFile();

function menu() {
    console.log("\n--- Tax manager ---");
    console.log("1. Add Register");
    console.log("2. Show Lis");
    console.log("3. Edit Register");
    console.log("4. Delete register"); 
    console.log("5. Exit");          

    rl.question("Opción: ", opt => {
        switch (opt) {
            case "1":
                addEntry();
                break;
            case "2":
                showList();
                break;
            case "3":
                editEntry();
                break;
            case "4":
                deleteEntry(); 
                break;
            case "5":
                rl.close();
                break;
            default:
                console.log("Invalid.");
                menu();
        }
    });
}

function addEntry() {
    rl.question("Description: ", description => {
        rl.question("Base Amount: ", baseAmount => {
            rl.question("Rate (ej. 0.15): ", taxRate => {
                taxEntries.push(
                    new TaxEntry(description, baseAmount, taxRate)
                );
                fm.saveToFile(taxEntries);
                menu();
            });
        });
    });
}

function showList() {
    console.log("\n--- Register to tax ---");
    if (taxEntries.length === 0) {
        console.log("No registers.");
    } else {
        taxEntries.forEach((e, index) => {
            console.log(`\n[${index + 1}] ${e.description}`);
            console.log(`  Base Amount: $${e.baseAmount.toFixed(2)}`);
            console.log(`  Rate: ${e.taxRate * 100}%`);
            console.log(`  Tax: $${e.taxAmount.toFixed(2)}`);
            console.log("-------------------------------");
        });
    }
    menu();
}

function showListNumbers() {
    console.log("\n--- Register to select ---");
    if (taxEntries.length === 0) {
        console.log("There are no records.");
    } else {
        taxEntries.forEach((e, index) => {
            console.log(`[${index + 1}] ${e.description}`);
        });
    }
}

function editEntry() {
    showListNumbers();
    rl.question("Enter the REGISTRATION NUMBER to edit: ", indexStr => {
        const index = parseInt(indexStr) - 1;

        if (index >= 0 && index < taxEntries.length) {
            const entryToEdit = taxEntries[index];

            rl.question("New Base Amount: ", newAmount => {
                rl.question("New Rate (ej. 0.15): ", newRate => {
                    entryToEdit.baseAmount = parseFloat(newAmount);
                    entryToEdit.taxRate = parseFloat(newRate);
                    entryToEdit.updateAmounts();

                    fm.saveToFile(taxEntries);
                    console.log(`\nRegister ${index + 1} updated.`);
                    menu();
                });
            });

        } else {
            console.log("\n Invalid.");
            menu();
        }
    });
}

function deleteEntry() {
    showListNumbers();
    if (taxEntries.length === 0) {
        menu();
        return;
    }
    
    rl.question("Enter the REGISTRATION NUMBER to DELETE: ", indexStr => {
        const index = parseInt(indexStr) - 1;

        if (index >= 0 && index < taxEntries.length) {
            const deletedEntry = taxEntries[index];

            // Elimina 1 elemento en la posición 'index'
            taxEntries.splice(index, 1); 
            
            fm.saveToFile(taxEntries);
            
            console.log(`\n Registro "${deletedEntry.description}" ELIMINATED.`);
            
        } else {
            console.log("\n Invalid.");
        }
        menu();
    });
}

console.log("Tax manager");
menu();