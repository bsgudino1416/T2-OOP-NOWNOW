public class TaxEntry {
    public String description;
    public double baseAmount;
    public double taxRate;
    public double taxAmount;

    // Constructor usado para crear nuevas entradas (y por el cargador JSON)
    public TaxEntry(String description, double baseAmount, double taxRate) {
        this.description = description;
        this.baseAmount = baseAmount;
        this.taxRate = taxRate;
        this.updateAmounts();
    }
    
    // Constructor sin argumentos requerido por Gson
    public TaxEntry() {}

    public void updateAmounts() {
        this.taxAmount = this.baseAmount * this.taxRate;
    }
}