import java.util.List;
import java.util.Scanner;

public class App {
    private static List<TaxEntry> taxEntries = FileManager.loadFromFile();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Gestor de Impuestos");
        menu();
    }

    private static void menu() {
        System.out.println("\n--- Gestor de Impuestos ---");
        System.out.println("1. Añadir Registro");
        System.out.println("2. Mostrar Lista");
        System.out.println("3. Editar Registro");
        System.out.println("4. Salir");
        System.out.print("Opción: ");

        String opt = scanner.nextLine();
        switch (opt) {
            case "1":
                addEntry();
                break;
            case "2":
                showList();
                break;
            case "3":
                editEntry();
                break;
            case "4":
                System.out.println("Saliendo...");
                break;
            default:
                System.out.println("Opción inválida.");
                menu();
        }
    }

    private static void addEntry() {
        System.out.print("Descripción: ");
        String description = scanner.nextLine();
        
        System.out.print("Monto Base: ");
        double baseAmount = Double.parseDouble(scanner.nextLine());
        
        System.out.print("Tasa (ej. 0.15): ");
        double taxRate = Double.parseDouble(scanner.nextLine());

        taxEntries.add(new TaxEntry(description, baseAmount, taxRate));
        FileManager.saveToFile(taxEntries);
        menu();
    }

    private static void showList() {
        System.out.println("\n--- Registros de Impuestos ---");
        if (taxEntries.isEmpty()) {
            System.out.println("No hay registros.");
        } else {
            for (int i = 0; i < taxEntries.size(); i++) {
                TaxEntry e = taxEntries.get(i);
                System.out.printf("\n[%d] %s%n", i + 1, e.description);
                System.out.printf("  Monto Base: $%.2f%n", e.baseAmount);
                System.out.printf("  Tasa: %.2f%%%n", e.taxRate * 100);
                System.out.printf("  Impuesto: $%.2f%n", e.taxAmount);
                System.out.println("-------------------------------");
            }
        }
        menu();
    }

    private static void showListNumbers() {
        System.out.println("\n--- Registros para Editar ---");
        for (int i = 0; i < taxEntries.size(); i++) {
            System.out.printf("[%d] %s%n", i + 1, taxEntries.get(i).description);
        }
    }

    private static void editEntry() {
        if (taxEntries.isEmpty()) {
            System.out.println("No hay registros para editar.");
            menu();
            return;
        }

        showListNumbers();
        System.out.print("Ingrese el NÚMERO del registro a editar: ");
        
        try {
            int index = Integer.parseInt(scanner.nextLine()) - 1;

            if (index >= 0 && index < taxEntries.size()) {
                TaxEntry entryToEdit = taxEntries.get(index);

                System.out.print("Nuevo Monto Base: ");
                double newAmount = Double.parseDouble(scanner.nextLine());
                
                System.out.print("Nueva Tasa (ej. 0.15): ");
                double newRate = Double.parseDouble(scanner.nextLine());
                
                entryToEdit.baseAmount = newAmount;
                entryToEdit.taxRate = newRate;
                entryToEdit.updateAmounts();

                FileManager.saveToFile(taxEntries);
                System.out.printf("\nRegistro %d actualizado.%n", index + 1);

            } else {
                System.out.println("\n⛔ Número de registro inválido.");
            }
        } catch (NumberFormatException e) {
            System.out.println("\n⛔ Entrada inválida.");
        }
        menu();
    }
}