public class TaxEntry {
    public String description;
    public double baseAmount;
    public double taxRate;
    public double taxAmount;

    public TaxEntry(String description, double baseAmount, double taxRate) {
        this.description = description;
        this.baseAmount = baseAmount;
        this.taxRate = taxRate;
        this.updateAmounts();
    }
    
    public TaxEntry() {}

    public void updateAmounts() {
        this.taxAmount = this.baseAmount * this.taxRate;
    }
}
