import java.util.List;
import java.util.Scanner;

public class main {
    private static List<TaxEntry> taxEntries = FileManager.loadFromFile();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Tax Manager");
        menu();
    }

    private static void menu() {
        System.out.println("\n--- Tax Manager ---");
        System.out.println("1. Add Record");
        System.out.println("2. Show List");
        System.out.println("3. Edit Record");
        System.out.println("4. Delete Record"); // NEW OPTION
        System.out.println("5. Exit");          // OPTION MOVED
        System.out.print("Option: ");

        String opt = scanner.nextLine();
        switch (opt) {
            case "1":
                addEntry();
                break;
            case "2":
                showList();
                break;
            case "3":
                editEntry();
                break;
            case "4": // NEW CASE
                deleteEntry();
                break;
            case "5": // MODIFIED CASE
                System.out.println("Exiting...");
                break;
            default:
                System.out.println("Invalid option.");
                menu();
        }
    }

    private static void addEntry() {
        try {
            System.out.print("Description: ");
            String description = scanner.nextLine();
            
            System.out.print("Base Amount: ");
            double baseAmount = Double.parseDouble(scanner.nextLine());
            
            System.out.print("Rate (e.g., 0.15): ");
            double taxRate = Double.parseDouble(scanner.nextLine());

            taxEntries.add(new TaxEntry(description, baseAmount, taxRate));
            FileManager.saveToFile(taxEntries);
            menu();
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid numerical input. Please try again.");
            menu();
        }
    }

    private static void showList() {
        System.out.println("\n--- Tax Records ---");
        if (taxEntries.isEmpty()) {
            System.out.println("No records found.");
        } else {
            for (int i = 0; i < taxEntries.size(); i++) {
                TaxEntry e = taxEntries.get(i);
                System.out.printf("\n[%d] %s%n", i + 1, e.description);
                System.out.printf("  Base Amount: $%.2f%n", e.baseAmount);
                System.out.printf("  Rate: %.2f%%%n", e.taxRate * 100);
                System.out.printf("  Tax: $%.2f%n", e.taxAmount);
                System.out.println("-------------------------------");
            }
        }
        menu();
    }

    private static void showListNumbers() {
        System.out.println("\n--- Records for Selection ---");
        if (taxEntries.isEmpty()) {
            System.out.println("No records found.");
        } else {
            for (int i = 0; i < taxEntries.size(); i++) {
                System.out.printf("[%d] %s%n", i + 1, taxEntries.get(i).description);
            }
        }
    }

    private static void editEntry() {
        if (taxEntries.isEmpty()) {
            System.out.println("No records to edit.");
            menu();
            return;
        }

        showListNumbers();
        System.out.print("Enter the NUMBER of the record to edit: ");
        
        try {
            int index = Integer.parseInt(scanner.nextLine()) - 1;

            if (index >= 0 && index < taxEntries.size()) {
                TaxEntry entryToEdit = taxEntries.get(index);

                System.out.print("New Base Amount: ");
                double newAmount = Double.parseDouble(scanner.nextLine());
                
                System.out.print("New Rate (e.g., 0.15): ");
                double newRate = Double.parseDouble(scanner.nextLine());
                
                entryToEdit.baseAmount = newAmount;
                entryToEdit.taxRate = newRate;
                entryToEdit.updateAmounts();

                FileManager.saveToFile(taxEntries);
                System.out.printf("\nRecord %d updated.%n", index + 1);

            } else {
                System.out.println("\nInvalid record number.");
            }
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid input.");
        }
        menu();
    }
    
    // FUNCTION TO DELETE A RECORD
    private static void deleteEntry() {
        if (taxEntries.isEmpty()) {
            System.out.println("No records to delete.");
            menu();
            return;
        }

        showListNumbers();
        System.out.print("Enter the NUMBER of the record to DELETE: ");
        
        try {
            int index = Integer.parseInt(scanner.nextLine()) - 1;

            if (index >= 0 && index < taxEntries.size()) {
                TaxEntry deletedEntry = taxEntries.remove(index); // Removes the element
                
                FileManager.saveToFile(taxEntries);
                System.out.printf("\nRecord \"%s\" DELETED.%n", deletedEntry.description);

            } else {
                System.out.println("\nInvalid record number.");
            }
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid input.");
        }
        menu();
    }
}
