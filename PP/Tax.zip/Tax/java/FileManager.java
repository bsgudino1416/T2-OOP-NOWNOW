import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class FileManager {
    private static final String JSON_FILE = "data/taxes.json";
    private static final Path DATA_DIR = Paths.get("data");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void saveToFile(List<TaxEntry> entries) {
        try {
            if (!Files.exists(DATA_DIR)) {
                Files.createDirectories(DATA_DIR);
            }
            try (FileWriter writer = new FileWriter(JSON_FILE)) {
                GSON.toJson(entries, writer);
            }
            // Translated: "Data saved to " + JSON_FILE
            System.out.println("Data saved to " + JSON_FILE);
        } catch (IOException e) {
            // Translated: "Error saving file: " + e.getMessage()
            System.out.println("Error saving file: " + e.getMessage());
        }
    }

    public static List<TaxEntry> loadFromFile() {
        if (!Files.exists(Paths.get(JSON_FILE))) {
            // Translated: "File does not exist, starting empty."
            System.out.println("File does not exist, starting empty.");
            return new ArrayList<>();
        }

        try (FileReader reader = new FileReader(JSON_FILE)) {
            Type listType = new TypeToken<ArrayList<TaxEntry>>(){}.getType();
            List<TaxEntry> entries = GSON.fromJson(reader, listType);
            
            // Recalcular montos después de cargar
            for (TaxEntry entry : entries) {
                entry.updateAmounts();
            }
            return entries;
        } catch (IOException e) {
            // Translated: "Error loading file, starting empty: " + e.getMessage()
            System.out.println("Error loading file, starting empty: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}