from tax_entry import TaxEntry
from fm import save_to_file, load_from_file

tax_entries = load_from_file()

def add_entry():
    description = input("Description: ")
    base_amount = input("Base Amount: ")
    tax_rate = input("Rate (e.g., 0.15): ")

    try:
        tax_entries.append(TaxEntry(description, base_amount, tax_rate))
        save_to_file(tax_entries)
    except ValueError:
        print("Invalid numerical input. Please try again.")
    menu()

def show_list():
    print("\n--- Tax Records ---")
    if not tax_entries:
        print("No records found.")
    else:
        for index, e in enumerate(tax_entries):
            print(f"\n[{index + 1}] {e.description}")
            print(f"  Base Amount: ${e.base_amount:.2f}")
            print(f"  Rate: {e.tax_rate * 100:.2f}%")
            print(f"  Tax: ${e.tax_amount:.2f}")
            print("-------------------------------")
    menu()

def show_list_numbers():
    print("\n--- Records for Selection ---")
    if not tax_entries:
        print("No records found.")
    else:
        for index, e in enumerate(tax_entries):
            print(f"[{index + 1}] {e.description}")

def edit_entry():
    if not tax_entries:
        print("No records to edit.")
        return menu()

    show_list_numbers()
    try:
        index_str = input("Enter the NUMBER of the record to edit: ")
        index = int(index_str) - 1

        if 0 <= index < len(tax_entries):
            entry_to_edit = tax_entries[index]

            new_amount = input("New Base Amount: ")
            new_rate = input("New Rate (e.g., 0.15): ")

            entry_to_edit.base_amount = float(new_amount)
            entry_to_edit.tax_rate = float(new_rate)
            entry_to_edit.update_amounts()

            save_to_file(tax_entries)
            print(f"\nRecord {index + 1} updated.")

        else:
            print("\nInvalid record number.")

    except ValueError:
        print("\nInvalid input.")
    menu()

def delete_entry():
    if not tax_entries:
        print("No records to delete.")
        return menu()

    show_list_numbers()
    try:
        index_str = input("Enter the NUMBER of the record to DELETE: ")
        index = int(index_str) - 1

        if 0 <= index < len(tax_entries):
            deleted_entry = tax_entries.pop(index) 
            
            save_to_file(tax_entries)
            print(f"\nRecord \"{deleted_entry.description}\" DELETED.")
        
        else:
            print("\nInvalid record number.")

    except ValueError:
        print("\nInvalid input.")
    menu()


def menu():
    print("\n--- Tax Manager ---")
    print("1. Add Record")
    print("2. Show List")
    print("3. Edit Record")
    print("4. Delete Record") 
    print("5. Exit")          

    opt = input("Option: ")
    if opt == "1":
        add_entry()
    elif opt == "2":
        show_list()
    elif opt == "3":
        edit_entry()
    elif opt == "4":
        delete_entry()
    elif opt == "5":
        print("Exiting...")
    else:
        print("Invalid option.")
        menu()

if __name__ == "__main__":
    print("Tax Manager")
    menu()