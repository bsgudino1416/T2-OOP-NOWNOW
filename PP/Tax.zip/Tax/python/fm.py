import json
import os
from tax_entry import TaxEntry

JSON_FILE = "data/taxes.json"

def save_to_file(entries):
    os.makedirs("data", exist_ok=True)

    data = []
    for e in entries:
        data.append({
            "description": e.description,
            "base_amount": e.base_amount,
            "tax_rate": e.tax_rate
        })

    with open(JSON_FILE, 'w') as f:
        json.dump(data, f, indent=3)
    print(f"Data save in {JSON_FILE}")

def load_from_file():
    if not os.path.exists(JSON_FILE):
        print("File does not exist, starting empty.")
        return []

    with open(JSON_FILE, 'r') as f:
        try:
            arr = json.load(f)
            return [TaxEntry(obj["description"], obj["base_amount"], obj["tax_rate"]) for obj in arr]
        except json.JSONDecodeError:
            print("Error reading JSON, starting empty.")
            return []