class TaxEntry:
    def __init__(self, description, base_amount, tax_rate):
        self.description = description
        self.base_amount = float(base_amount)
        self.tax_rate = float(tax_rate)
        self.tax_amount = self.calculate_tax()

    def calculate_tax(self):
        return self.base_amount * self.tax_rate

    def update_amounts(self):
        self.tax_amount = self.calculate_tax()