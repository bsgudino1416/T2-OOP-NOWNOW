class Cathedral {
    constructor(id, name, country, yearBuilt) {
        this.id = id;
        this.name = name;
        this.country = country;
        this.yearBuilt = yearBuilt;
    }
}

module.exports = Cathedral;
