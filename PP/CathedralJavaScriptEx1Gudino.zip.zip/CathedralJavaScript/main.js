const readline = require("readline");
const Cathedral = require("./Cathedral");
const fm = require("./fileManager");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let cathedrals = fm.loadFromFile();

function menu() {
    console.log("\n1. Add Cathedral");
    console.log("2. Show list");
    console.log("3. Save in JSON");
    console.log("4. Exit");

    rl.question("Opción: ", opt => {
        switch (opt) {

            case "1":
                rl.question("ID: ", id => {
                    rl.question("Name: ", name => {
                        rl.question("Country: ", country => {
                            rl.question("Year of construction: ", year => {
                                cathedrals.push(
                                    new Cathedral(id, name, country, parseInt(year))
                                );
                                menu();
                            });
                        });
                    });
                });
                break;

	    case "2":
    		cathedrals.forEach(c => {
      		console.log(`ID: ${c.id}`);
        	console.log(`Name: ${c.name}`);
        	console.log(`Country: ${c.country}`);
        	console.log(`Year of construction: ${c.yearBuilt}`);
        	console.log("-------------------------------");
    		});
    		menu();
    		break;

            case "3":
                fm.saveToFile(cathedrals);
                menu();
                break;

            case "4":
                console.log("Exit...");
                rl.close();
                break;

            default:
                console.log("Invalid...");
                menu();
        }
    });
}

console.log("Cathedral Manager");
menu();
